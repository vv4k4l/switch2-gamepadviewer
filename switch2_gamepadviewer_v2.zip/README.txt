Switch 2 Joy-Con style GamePad Viewer Beta pack — v2
Canvas/base: 750 x 630 px.

BASE:
Connected State Image URL -> base.png (Width 750, Height 630)
Disconnected State Image URL -> disconnected.png (Width 750, Height 630)

Every other PNG is tightly cropped. Use placements.csv:
Width = width_px
Height = height_px
Top Position = top_px
Left Position = left_px

Mapping:
Left Trigger -> lt-pressed.png
Right Trigger -> rt-pressed.png
Left Bumper -> lb-pressed.png
Right Bumper -> rb-pressed.png
PS/Guide -> guide-pressed.png
Player Indicator -> p1.png, p2.png, p3.png, p4.png
Start -> start-pressed.png (+)
Select -> select-pressed.png (-)
Left Thumbstick -> left-stick.png / left-stick-pressed.png
Right Thumbstick -> right-stick.png / right-stick-pressed.png
A/Cross -> a-pressed.png
B/Circle -> b-pressed.png
X/Square -> x-pressed.png
Y/Triangle -> y-pressed.png
D-Pad -> dpad-up/down/left/right-pressed.png

Extra files:
capture-pressed.png
c-pressed.png
These can only animate if the editor lets you add a custom part bound to those inputs.
